#include <iostream>
#include "bin_tree.h"

using namespace std;


int main() {
//    Node *root = Node::add_node(1);
//    root->left = Node::add_node(2);
//    root->right = Node::add_node(3);
//    root->left->left = Node::add_node(4);
//    root->left->right = Node::add_node(5);

//    Node::travel_pre_order(root);//all left then right
//    cout << '\n';
//    Node::travel_in_order(root);//left-mid-right
//    cout << '\n';
//    Node::travel_post_order(root); // down->up

//    Node *root1 = BST::create_bin_search_tree(5, 3, 4, 2, 7, 8);
    Node *root1 = BST::create_bin_search_tree(10, 5, 3, 4, 2, 1, 6, 7, 9, 8, 11);

    BST::place_node(root1, 10);

    BST::travel_post_order(root1);

    cout << '\n';
    Node *res;
    res = BST::search_elem(root1, 6);
    BST::print_node(res);

    BST::del_node(root1, 5);
    BST::travel_post_order(root1);
    cout << '\n';
    res = BST::search_elem(root1, 5);

    BST::print_node(res);
    return 0;
}
